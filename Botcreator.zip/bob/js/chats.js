"use strict";
/* ============================================================
   Chat view: sessions, message rendering, streaming,
   regenerate / edit / delete message actions
   ============================================================ */

/* ---------- opening chats & sessions ---------- */

function openBotChat(botId) {
  const sessions = DB.botSessions(botId);
  if (sessions.length) openSession(sessions[0].id);
  else openSession(DB.createSession(botId).id);
}

function openSession(sessionId) {
  const s = DB.session(sessionId);
  if (!s) return;
  if (State.generating) stopGeneration();
  State.view = "chat";
  State.botId = s.botId;
  State.sessionId = sessionId;
  State.msgs = DB.getMsgs(sessionId);
  closeHistoryPopover();
  showView();
  renderChatHeader();
  renderMessages();
  renderSidebar();
  $("msg-input").focus();
}

function newChat() {
  if (!State.botId) return;
  const s = DB.createSession(State.botId);
  openSession(s.id);
  toast("New chat started");
}

function renderChatHeader() {
  const bot = DB.bot(State.botId), s = DB.session(State.sessionId);
  if (!bot || !s) return;
  const holder = $("chat-avatar-holder");
  holder.innerHTML = "";
  holder.appendChild(avatarNode(bot, "md"));
  $("chat-name").textContent = bot.name;
  $("chat-session-title").textContent = s.title;
}

/* ---------- history popover ---------- */

function toggleHistoryPopover() {
  const pop = $("history-popover");
  if (pop.hidden) renderHistoryPopover();
  pop.hidden = !pop.hidden;
}
function closeHistoryPopover() { $("history-popover").hidden = true; }

function renderHistoryPopover() {
  const pop = $("history-popover");
  pop.innerHTML = "";

  const newBtn = iconBtn("plus", "pop-new", "Start a fresh chat", "New Chat");
  newBtn.onclick = newChat;
  pop.appendChild(newBtn);

  for (const s of DB.botSessions(State.botId)) {
    const row = el("div", "pop-row" + (s.id === State.sessionId ? " active" : ""));
    const title = el("span", "pop-title", s.title);
    title.title = s.title;
    row.appendChild(title);
    row.appendChild(el("span", "pop-time", timeAgo(s.updatedAt)));

    const ren = iconBtn("edit", "pop-act", "Rename");
    ren.onclick = e => { e.stopPropagation(); startRenameSession(s, row, title); };
    row.appendChild(ren);

    const del = iconBtn("trash", "pop-act del", "Delete chat");
    del.onclick = e => { e.stopPropagation(); deleteSessionUI(s.id); };
    row.appendChild(del);

    row.onclick = () => openSession(s.id);
    pop.appendChild(row);
  }
}

function startRenameSession(s, row, titleEl) {
  const input = el("input", "pop-rename-input");
  input.type = "text";
  input.value = s.title;
  input.maxLength = 60;
  row.replaceChild(input, titleEl);
  input.focus();
  input.select();
  const commit = () => {
    const v = input.value.trim();
    if (v) {
      s.title = v;
      DB.saveSessions();
      if (s.id === State.sessionId) renderChatHeader();
      renderSidebar();
    }
    renderHistoryPopover();
  };
  input.onkeydown = e => {
    if (e.key === "Enter") input.blur();
    if (e.key === "Escape") { input.onblur = null; renderHistoryPopover(); }
    e.stopPropagation();
  };
  input.onblur = commit;
  input.onclick = e => e.stopPropagation();
}

function deleteSessionUI(id) {
  if (!confirm("Delete this chat? Its messages will be gone forever.")) return;
  const wasActive = State.sessionId === id;
  const botId = DB.session(id)?.botId;
  DB.deleteSession(id);
  toast("Chat deleted");
  if (wasActive) {
    if (State.generating) stopGeneration();
    State.sessionId = null;
    State.msgs = [];
    openBotChat(botId); // opens most recent remaining session or a fresh one
  } else {
    renderSidebar();
    if (State.view === "chat" && !$("history-popover").hidden) renderHistoryPopover();
    if (State.view === "home") renderHome();
  }
}

/* ---------- message rendering ---------- */

function isNearBottom() {
  const b = $("messages");
  return b.scrollHeight - b.scrollTop - b.clientHeight < 140;
}
function scrollBottom() {
  const b = $("messages");
  b.scrollTop = b.scrollHeight;
  updateScrollBtn();
}
/* only autoscroll while streaming if the user hasn't scrolled up to read */
function scrollBottomIfNear() {
  if (!State.userScrolledUp) scrollBottom();
}
function updateScrollBtn() {
  const btn = $("scroll-bottom-btn");
  if (!btn) return;
  const show = !isNearBottom();
  State.userScrolledUp = show;
  btn.classList.toggle("show", show);
}

function renderMessages() {
  const bot = DB.bot(State.botId);
  const box = $("messages");
  box.innerHTML = "";
  if (!bot) return;
  const s = DB.session(State.sessionId);
  if (bot.greeting) {
    box.appendChild(msgNode(
      { role: "assistant", content: bot.greeting, ts: s ? s.createdAt : Date.now(), greeting: true },
      -1, bot));
  }
  State.msgs.forEach((m, i) => box.appendChild(msgNode(m, i, bot)));
  scrollBottom();
}

function msgNode(m, i, bot) {
  const isUser = m.role === "user";
  const wrap = el("div", "msg " + (isUser ? "user" : "bot"));
  if (i >= 0) wrap.dataset.idx = i;
  if (!isUser) wrap.appendChild(avatarNode(bot, "sm"));

  const col = el("div", "msg-col");
  const bubble = el("div", "msg-bubble" + (m.error ? " error" : ""));
  if (isUser || m.error) bubble.textContent = m.content;
  else { bubble.innerHTML = renderMarkdown(m.content); animateRolls(bubble); }
  bubble.title = m.ts ? new Date(m.ts).toLocaleString() : "";
  col.appendChild(bubble);

  if (!m.greeting && i >= 0) {
    const meta = el("div", "msg-meta");

    const act = el("div", "msg-actions");
    const mkBtn = (name, title, fn) => {
      const b = iconBtn(name, "", title);
      b.onclick = fn;
      act.appendChild(b);
    };
    mkBtn("copy", "Copy", () => copyText(m.content));
    if (isUser) mkBtn("edit", "Edit & resend", () => editUserMessage(i));
    mkBtn("trash", "Delete message", () => deleteMessage(i));
    meta.appendChild(act);

    const info = el("div", "msg-info");
    if (m.stats) info.appendChild(el("span", "", m.stats.tok + " tok · " + m.stats.tps + "/s"));
    if (m.ts) info.appendChild(el("span", "", new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })));
    meta.appendChild(info);

    col.appendChild(meta);
  }

  wrap.appendChild(col);
  return wrap;
}

/* ---------- sending & streaming ---------- */

function setSendButton(stop) {
  const b = $("send-btn");
  b.classList.toggle("stop", stop);
  b.innerHTML = icon(stop ? "stop" : "send");
  b.title = stop ? "Stop generating" : "Send";
}

function autoGrow() {
  const input = $("msg-input");
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 170) + "px";
}

/* live character count + rough token estimate under the input */
function updateInputCount() {
  const out = $("input-count");
  if (!out) return;
  const len = $("msg-input").value.length;
  if (!len) { out.textContent = ""; out.classList.remove("over"); return; }
  const tok = Math.max(1, Math.round(len / 4));
  out.textContent = len + " chars · ~" + tok + " tok";
  out.classList.toggle("over", len > 8000);
}

function persistMsgs() {
  DB.saveMsgs(State.sessionId, State.msgs);
  const s = DB.session(State.sessionId);
  if (!s) return;
  s.updatedAt = Date.now();
  const last = State.msgs[State.msgs.length - 1];
  s.snippet = last ? ((last.role === "user" ? "You: " : "") + last.content.slice(0, 60)) : "";
  if (s.title === "New Chat") {
    const firstUser = State.msgs.find(m => m.role === "user");
    if (firstUser) s.title = firstUser.content.slice(0, 42);
  }
  DB.saveSessions();
  renderChatHeader();
  renderSidebar();
}

function buildApiMessages() {
  const bot = DB.bot(State.botId);
  let sys = bot.prompt || "You are a helpful assistant.";
  if (bot.scenario) sys += "\n\nScenario: " + bot.scenario;
  if (bot.example) sys += "\n\nExample conversation showing your exact style:\n" + bot.example;
  const persona = DB.activePersona();
  if (persona) {
    sys += "\n\nThe user's name is " + persona.name + ".";
    if (persona.desc) sys += "\nAbout the user: " + persona.desc;
  }
  if (bot.nickname) sys += "\nYou like to call the user \"" + bot.nickname + "\".";
  sys += "\n\nFormatting: whenever you write any multi-line code, a full snippet, a config file, or " +
    "anything meant to be copied/run/saved — ALWAYS wrap it in a triple-backtick fenced code block with " +
    "the language named right after the backticks (e.g. ```python or ```javascript), never as plain text " +
    "or inline `code` — fenced blocks get syntax highlighting plus working Copy and Save-to-file buttons " +
    "that plain text does not. Use inline `code` only for short inline references (a variable name, a " +
    "single command). " +
    "You can naturally use **bold**, *italic*, `code`, ==highlighted text==, " +
    "{green}success{/green}/{red}danger{/red}/{blue}info{/blue} colored text, [[Key]] for keyboard keys, " +
    "(pill: label) for small badges, tables, numbered/bulleted lists, task lists (- [ ]), " +
    "> [!note]/[!tip]/[!warning] callouts, ```chart``` bar charts, ```timeline``` step trackers " +
    "(e.g. \"Step 1: ...\" per line), Term:: definition lists, ```details: Summary text``` for a " +
    "click-to-expand section (put the hidden content on the lines inside), and ```poll``` or ```choices``` " +
    "with one option per line to offer the user clickable reply buttons (great for \"what should I do?\" " +
    "moments). Use ```stats``` (one \"Label: value\" per line) for a row of big number cards, or " +
    "```stats:bar``` (one \"Label: current/max\" per line) for HP/mana-style progress bars. Use ```tabs``` " +
    "with \"## Section Title\" lines to split content the user can click between instead of one long wall " +
    "of text. Use ```roll``` or ```dice``` (one dice notation like \"1d20\" or \"2d6+3\" per line) whenever " +
    "a dice roll or random chance is relevant — it animates and reveals a real result, don't just state a " +
    "number yourself. Use ```rate: your question``` with either a numeric range on the next line (e.g. " +
    "\"1-5\") or a comma-separated list of options (e.g. \"Easy, Medium, Hard\") to let the user pick an " +
    "answer with one click instead of typing. And use ```story```/```poem``` blocks whenever the user asks " +
    "you to write a story, poem, script, " +
    "or other long-form creative writing — put ONLY the piece itself inside the fence (no extra commentary " +
    "inside it) so it renders as a clean, copyable card. For ANY math, ALWAYS use ```math``` fenced blocks " +
    "with this app's plain notation — NEVER LaTeX (no $, no \\frac{}{}, no \\times, no \\cdot, no backslash " +
    "commands of any kind, since they will NOT render and will show up as broken raw text). Inside a " +
    "```math``` block, one expression per line, write x^2 for exponents, sqrt(x) for roots, a/b for " +
    "fractions (e.g. 2/5 * 3/4, NOT \\frac{2}{5}\\times\\frac{3}{4}), and ```calc``` blocks (same plain " +
    "notation) when you want the app to actually compute and verify a numeric result for you. Use ```math``` " +
    "for ALL math, even a single short equation. " +
    "Any fenced code block automatically gets a Save-to-file download button (name the file by writing e.g. " +
    "```html:index.html``` or ```python:script.py``` right after the language), and a ```html``` block " +
    "additionally gets a live Preview button that renders the page right in the chat. Prefer writing a " +
    "complete HTML page as ONE single ```html``` block with inline <style>/<script> when possible, since " +
    "that's the simplest and most reliable to preview/save. If you DO split into separate ```html```, " +
    "```css```, and ```javascript``` files (e.g. because the user asked for separate files), place them " +
    "immediately adjacent with no other text between them — the app automatically detects that pattern and " +
    "stitches the CSS/JS into the HTML preview, so the Preview button still works correctly either way. " +
    "Instead of emoji, prefer this app's own icon set with :name: syntax. There are almost 2000 icons " +
    "available, but stick close to this confirmed list rather than inventing exotic names — an unrecognized " +
    "name either falls back to a plain emoji automatically (for common everyday words) or, failing that, " +
    "prints as harmless plain text, so it's low-risk to try a plausible common word, but the list below is " +
    "guaranteed to render as a real icon: " +
    ":star: :heart: :check: :x: :plus: :minus: :arrow-right: :arrow-up: :flag: :pin: :rocket: :zap: " +
    ":settings: :search: :code: :terminal: :wifi: :battery: :camera: :mic: :sun: :moon: :cloud: :wind: " +
    ":flame: :droplet: :waves: :tree-deciduous: :palmtree: :mountain: :flower: :snowflake: :apple: :pizza: " +
    ":coffee: :cake: :egg: :salad: :cookie: :wheat: :bike: :car: :plane: :train: :ship: :gamepad: :dice-5: " +
    ":volleyball: :briefcase: :folder: :file: :mail: :calendar: :clock: :book: :pencil: :pen: :scissors: " +
    ":paperclip: :ruler: :calculator: :smile: :laugh: :frown: :angry: :meh: :brain: :thumbs-up: :handshake: " +
    ":user: :users: :hand: :sparkles: :gem: :crown: :key: :shield: :sword: :target: :lightbulb: " +
    ":circle-help: :alert-triangle: :info: :trophy: :medal: :award: :banknote: :wallet: :piggy-bank: " +
    ":backpack: :school: :graduation-cap: :link: :share-2: :bookmark: :map: :compass: :umbrella: " +
    ":thermometer: :pill: :stethoscope: :syringe: :bone: — since they render as crisp icons matching the " +
    "UI. Plain emoji you type will also auto-convert to the closest icon when one exists. When it " +
    "genuinely makes a reply " +
    "clearer, sprinkle these into normal conversation like a person texting with rich formatting, not just " +
    "when explicitly asked. Don't overdo it or force it into every message.";
  const arr = [{ role: "system", content: sys }];
  if (bot.greeting) arr.push({ role: "assistant", content: bot.greeting });
  for (const m of State.msgs) {
    if (!m.error) arr.push({ role: m.role, content: m.content });
  }
  return arr;
}

async function sendMessage() {
  if (State.generating) { stopGeneration(); return; }
  const input = $("msg-input");
  const text = input.value.trim();
  if (!text || !State.sessionId) return;
  input.value = "";
  autoGrow();
  updateInputCount();
  State.msgs.push({ id: uid("m"), role: "user", content: text, ts: Date.now() });
  persistMsgs();
  renderMessages();
  await generate();
}

/* a reply that hit the token limit mid code-fence (odd number of ```)
   or was flagged "length" by the server is very likely cut off */
function looksCutOff(text, finishReason) {
  if (finishReason === "length") return true;
  const fences = (text.match(/^```/gm) || []).length;
  return fences % 2 === 1;
}

const MAX_AUTO_CONTINUES = 3;

async function generate() {
  const bot = DB.bot(State.botId);
  if (!bot) return;
  State.generating = true;
  setSendButton(true);

  const box = $("messages");
  const wrap = el("div", "msg bot");
  wrap.appendChild(avatarNode(bot, "sm"));
  const col = el("div", "msg-col");
  const bubble = el("div", "msg-bubble streaming");
  /* typing indicator: three bouncing dots until the first token lands */
  const typing = el("div", "typing");
  typing.innerHTML = "<span></span><span></span><span></span>";
  bubble.appendChild(typing);
  const cursor = el("span", "cursor");
  col.appendChild(bubble);
  wrap.appendChild(col);
  box.appendChild(wrap);
  scrollBottom();

  let reply = "";
  let chunks = 0;
  let firstToken = true;
  const t0 = performance.now();
  State.abort = new AbortController();

  const onDelta = d => {
    if (firstToken) { typing.remove(); bubble.appendChild(cursor); firstToken = false; }
    reply += d;
    bubble.textContent = reply;
    bubble.appendChild(cursor);
    scrollBottomIfNear();
  };

  try {
    let result = await streamChat({
      messages: buildApiMessages(),
      temperature: bot.temp ?? 0.8,
      topP: bot.topP,
      signal: State.abort.signal,
      onDelta
    });
    chunks = result.chunks;

    let continues = 0;
    while (DB.settings.autoContinue && looksCutOff(reply, result.finishReason) &&
           continues < MAX_AUTO_CONTINUES) {
      continues++;
      const contMessages = buildApiMessages();
      contMessages.push({ role: "assistant", content: reply });
      contMessages.push({ role: "user", content: "Continue exactly where you left off. Do not repeat any earlier text, do not add commentary — just continue the response (e.g. finish the code block/file) from the exact cutoff point." });
      result = await streamChat({
        messages: contMessages,
        temperature: bot.temp ?? 0.8,
        topP: bot.topP,
        signal: State.abort.signal,
        onDelta
      });
      chunks += result.chunks;
    }

    finishReply(reply, chunks, t0, false);
  } catch (err) {
    if (err.name === "AbortError") {
      finishReply(reply, chunks, t0, true);
    } else {
      const hint = /Failed to fetch|NetworkError|load failed/i.test(err.message)
        ? "Can't reach the server at " + apiBase() +
          "\n\n• Is your AI model server running?\n• Check the URL in ⚙️ Settings.\n• If it IS running, it may need CORS enabled."
        : err.message;
      State.msgs.push({ id: uid("m"), role: "assistant", content: "⚠️ " + hint, ts: Date.now(), error: true });
      persistMsgs();
      renderMessages();
      checkConnection();
    }
  } finally {
    State.generating = false;
    State.abort = null;
    setSendButton(false);
  }
}

function finishReply(reply, chunks, t0, stopped) {
  if (reply) {
    const secs = Math.max(0.05, (performance.now() - t0) / 1000);
    const tok = chunks || Math.max(1, Math.round(reply.length / 4));
    State.msgs.push({
      id: uid("m"), role: "assistant", content: reply, ts: Date.now(),
      stats: { tok, tps: (tok / secs).toFixed(1) }
    });
  } else {
    State.msgs.push({
      id: uid("m"), role: "assistant", ts: Date.now(), error: true,
      content: stopped ? "(stopped)" : "(no response — is a model loaded on the server?)"
    });
  }
  persistMsgs();
  renderMessages();
}

function stopGeneration() {
  if (State.abort) State.abort.abort();
}

/* ---------- message actions ---------- */

/* export the open chat as a readable Markdown transcript */
function exportCurrentChat() {
  const bot = DB.bot(State.botId), s = DB.session(State.sessionId);
  if (!bot || !s) { toast("Open a chat first"); return; }
  const persona = DB.activePersona();
  const you = persona ? persona.name : "You";
  const lines = ["# " + bot.name + " — " + s.title, "", "_Exported " + new Date().toLocaleString() + "_", ""];
  if (bot.greeting) lines.push("**" + bot.name + ":** " + bot.greeting, "");
  for (const m of State.msgs) {
    if (m.error) continue;
    const who = m.role === "user" ? you : bot.name;
    lines.push("**" + who + ":** " + m.content, "");
  }
  downloadText(lines.join("\n"), slugify(bot.name + "-" + s.title) + ".md", "text/markdown");
  toast("Chat exported");
}

function deleteMessage(i) {
  if (State.generating) return;
  State.msgs.splice(i, 1);
  persistMsgs();
  renderMessages();
}

function editUserMessage(i) {
  if (State.generating) return;
  const m = State.msgs[i];
  if (!m) return;
  renderMessages();
  const bubble = $("messages").querySelector('[data-idx="' + i + '"] .msg-bubble');
  if (!bubble) return;
  bubble.innerHTML = "";

  const ta = el("textarea", "edit-ta");
  ta.value = m.content;
  bubble.appendChild(ta);

  const row = el("div", "edit-row");
  const cancelB = el("button", "btn sm", "Cancel");
  cancelB.type = "button";
  const saveB = el("button", "btn primary sm", "Save & Resend");
  saveB.type = "button";
  row.appendChild(cancelB);
  row.appendChild(saveB);
  bubble.appendChild(row);
  ta.focus();

  cancelB.onclick = () => renderMessages();
  saveB.onclick = async () => {
    const v = ta.value.trim();
    if (!v) return;
    m.content = v;
    State.msgs = State.msgs.slice(0, i + 1); // everything after gets regenerated
    persistMsgs();
    renderMessages();
    await generate();
  };
  ta.onkeydown = e => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) saveB.onclick();
    if (e.key === "Escape") renderMessages();
    e.stopPropagation();
  };
}
