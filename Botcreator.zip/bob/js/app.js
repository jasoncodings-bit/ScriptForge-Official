"use strict";
/* ============================================================
   App state, view switching, sidebar, global wiring, init
   ============================================================ */

const State = {
  view: "home",        // "home" | "chat"
  botId: null,
  sessionId: null,
  msgs: [],
  generating: false,
  abort: null,
  userScrolledUp: false
};

function showView() {
  $("home-view").hidden = State.view !== "home";
  $("chat-view").hidden = State.view !== "chat";
}

function goHome() {
  if (State.generating) stopGeneration();
  State.view = "home";
  State.botId = null;
  State.sessionId = null;
  State.msgs = [];
  closeHistoryPopover();
  showView();
  renderHome();
  renderSidebar();
}

/* re-render everything that shows bot data */
function refreshAll() {
  renderSidebar();
  if (State.view === "home") renderHome();
}

/* ---------- sidebar: recent chats across all bots ---------- */

function renderSidebar() {
  const list = $("session-list");
  list.innerHTML = "";
  const q = ($("sidebar-search").value || "").trim().toLowerCase();
  const sessions = DB.sessions.slice().sort((a, b) => b.updatedAt - a.updatedAt);

  for (const s of sessions) {
    const bot = DB.bot(s.botId);
    if (!bot) continue;
    const hay = (bot.name + " " + s.title + " " + (s.snippet || "")).toLowerCase();
    if (q && !hay.includes(q)) continue;

    const row = el("div", "session-item" + (s.id === State.sessionId ? " active" : ""));
    row.appendChild(avatarNode(bot, "sm"));

    const info = el("div", "s-info");
    const top = el("div", "s-top");
    top.appendChild(el("span", "s-bot", bot.name));
    top.appendChild(el("span", "s-time", timeAgo(s.updatedAt)));
    info.appendChild(top);
    info.appendChild(el("div", "s-snippet", s.snippet || s.title));
    row.appendChild(info);

    const del = iconBtn("trash", "s-del", "Delete chat");
    del.onclick = e => { e.stopPropagation(); deleteSessionUI(s.id); };
    row.appendChild(del);

    row.onclick = () => openSession(s.id);
    list.appendChild(row);
  }

  if (!list.children.length) {
    list.appendChild(el("div", "empty-list",
      q ? "No chats match your search" : "No chats yet — pick a bot on the Home screen to start talking!"));
  }
}

/* ---------- theme ---------- */

function applyTheme() {
  document.documentElement.dataset.theme = DB.settings.theme || "dark";
  $("theme-btn").innerHTML = icon(DB.settings.theme === "light" ? "moon" : "sun");
}
function toggleTheme() {
  DB.settings.theme = DB.settings.theme === "light" ? "dark" : "light";
  DB.saveSettings();
  applyTheme();
}

/* ---------- init ---------- */

function wireStaticIcons() {
  $("logo-holder").innerHTML = icon("logo");
  $("home-btn").innerHTML = icon("home") + "<span>Home</span>";
  $("create-bot-btn").innerHTML = icon("plus") + "<span>Create Bot</span>";
  $("settings-btn").innerHTML = icon("settings") + "<span>Settings</span>";
  $("back-btn").innerHTML = icon("back");
  $("new-chat-btn").innerHTML = icon("plus") + "<span>New Chat</span>";
  $("history-btn").innerHTML = icon("history") + "<span>History</span>";
  $("export-chat-btn").innerHTML = icon("download") + "<span>Export</span>";
  $("edit-bot-btn").innerHTML = icon("edit") + "<span>Edit</span>";
  $("scroll-bottom-btn").innerHTML = icon("chevron-down");
  $("refresh-models-btn").innerHTML = icon("refresh");
  $("persona-add-btn").innerHTML = icon("plus");
  $("persona-del-btn").innerHTML = icon("trash");
  $("export-btn").innerHTML = icon("download") + "<span>Export backup</span>";
  $("import-btn").innerHTML = icon("upload") + "<span>Import backup / bot</span>";
  $("reset-btn").innerHTML = icon("alert") + "<span>Reset everything</span>";
  setSendButton(false);
}

function init() {
  DB.init();
  wireStaticIcons();
  applyTheme();
  applyDyslexiaFont();

  /* sidebar */
  $("home-btn").onclick = goHome;
  $("create-bot-btn").onclick = () => openBotEditor(null);
  $("theme-btn").onclick = toggleTheme;
  $("sidebar-search").addEventListener("input", renderSidebar);
  $("conn-status").onclick = checkConnection;

  /* home */
  $("home-search").addEventListener("input", renderHome);

  /* chat */
  $("back-btn").onclick = goHome;
  $("new-chat-btn").onclick = newChat;
  $("history-btn").onclick = e => { e.stopPropagation(); toggleHistoryPopover(); };
  $("edit-bot-btn").onclick = () => State.botId && openBotEditor(State.botId);
  $("export-chat-btn").onclick = exportCurrentChat;
  $("send-btn").onclick = sendMessage;

  /* jump-to-latest button + show/hide it as the user scrolls */
  $("scroll-bottom-btn").onclick = () => { State.userScrolledUp = false; scrollBottom(); };
  $("messages").addEventListener("scroll", updateScrollBtn, { passive: true });

  const input = $("msg-input");
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  input.addEventListener("input", () => { autoGrow(); updateInputCount(); });
  updateInputCount();

  /* code-block copy buttons + spoiler reveal + details toggle +
     choice buttons + universal text-copy (event delegation) */
  $("messages").addEventListener("click", e => {
    const spoiler = e.target.closest(".spoiler");
    if (spoiler) { spoiler.classList.add("revealed"); return; }

    const summary = e.target.closest(".details-summary");
    if (summary) {
      const body = document.getElementById(summary.dataset.target);
      const open = summary.getAttribute("aria-expanded") === "true";
      summary.setAttribute("aria-expanded", String(!open));
      if (body) body.hidden = open;
      return;
    }

    const choice = e.target.closest(".choice-btn");
    if (choice) {
      const group = choice.closest(".pollblock");
      group.querySelectorAll(".choice-btn").forEach(b => b.disabled = true);
      choice.classList.add("picked");
      $("msg-input").value = choice.textContent;
      sendMessage();
      return;
    }

    const rate = e.target.closest(".rate-btn");
    if (rate) {
      const group = rate.closest(".rateblock");
      group.querySelectorAll(".rate-btn").forEach(b => b.disabled = true);
      rate.classList.add("picked");
      $("msg-input").value = rate.textContent;
      sendMessage();
      return;
    }

    const tabHead = e.target.closest(".tab-head");
    if (tabHead) {
      const gid = tabHead.dataset.tabgroup, idx = tabHead.dataset.tabindex;
      const scope = tabHead.closest(".tabsblock");
      scope.querySelectorAll('.tab-head[data-tabgroup="' + gid + '"]').forEach(b =>
        b.classList.toggle("active", b.dataset.tabindex === idx));
      scope.querySelectorAll('.tab-panel[data-tabgroup="' + gid + '"]').forEach(p =>
        p.classList.toggle("active", p.dataset.tabindex === idx));
      return;
    }

    const dlBtn = e.target.closest(".code-download");
    if (dlBtn) {
      const code = dlBtn.closest(".codeblock")?.querySelector("pre code");
      if (!code) return;
      downloadText(code.textContent, dlBtn.dataset.filename || "snippet.txt", "text/plain");
      dlBtn.classList.add("copied");
      dlBtn.innerHTML = icon("check") + "<span>Saved</span>";
      setTimeout(() => {
        dlBtn.classList.remove("copied");
        dlBtn.innerHTML = icon("download") + "<span>Save</span>";
      }, 1600);
      return;
    }

    const previewBtn = e.target.closest(".code-preview-btn");
    if (previewBtn) {
      const pane = document.getElementById(previewBtn.dataset.target);
      const code = previewBtn.closest(".codeblock")?.querySelector("pre code");
      if (!pane || !code) return;
      const open = !pane.hidden;
      if (open) {
        pane.hidden = true;
        pane.querySelector("iframe").remove();
        previewBtn.innerHTML = icon("eye") + "<span>Preview</span>";
      } else {
        const iframe = document.createElement("iframe");
        iframe.sandbox = "allow-scripts";
        iframe.title = "HTML preview";
        iframe.srcdoc = pane.dataset.previewSrc || code.textContent;
        pane.appendChild(iframe);
        pane.hidden = false;
        previewBtn.innerHTML = icon("x") + "<span>Hide</span>";
      }
      return;
    }

    const btn = e.target.closest(".code-copy");
    if (!btn) return;
    const code = btn.closest(".codeblock")?.querySelector("pre code")
      || btn.closest(".proseblock")?.querySelector(".proseblock-body")
      || btn.closest(".mathblock")?.querySelector(".mathblock-body");
    if (!code) return;
    copyText(code.textContent);
    btn.classList.add("copied");
    btn.innerHTML = icon("check") + "<span>Copied</span>";
    setTimeout(() => {
      btn.classList.remove("copied");
      btn.innerHTML = icon("copy") + "<span>Copy</span>";
    }, 1600);
  });

  /* modals & editor */
  wireBotEditor();
  wireSettings();
  for (const id of ["bot-modal", "settings-modal"]) {
    $(id).addEventListener("mousedown", e => {
      if (e.target === $(id)) $(id).classList.remove("open");
    });
  }

  /* global keys + click-away for popover */
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      $("bot-modal").classList.remove("open");
      $("settings-modal").classList.remove("open");
      closeHistoryPopover();
    }
    if (e.key === "k" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      $("sidebar-search").focus();
    }
  });
  document.addEventListener("click", e => {
    if (!e.target.closest("#history-wrap")) closeHistoryPopover();
  });

  /* stop nice-to-know: warn if leaving mid-generation */
  window.addEventListener("beforeunload", e => {
    if (State.generating) e.preventDefault();
  });

  showView();
  renderHome();
  renderSidebar();
  checkConnection();
  setInterval(checkConnection, 30000);
}

document.addEventListener("DOMContentLoaded", init);

/* ```roll```/```dice``` blocks render with a "?" placeholder and their
   real result stashed in data-final; animate a quick spin then reveal it */
function animateRolls(container) {
  const rows = container.querySelectorAll(".roll-row[data-final]");
  rows.forEach((row, i) => {
    const die = row.querySelector(".roll-die");
    if (!die) return;
    const final = row.dataset.final;
    let ticks = 0;
    const maxTicks = 8 + i * 3;
    const spin = setInterval(() => {
      ticks++;
      if (ticks >= maxTicks) {
        clearInterval(spin);
        die.textContent = final;
        die.classList.remove("rolling");
        die.classList.add("landed");
      } else {
        die.textContent = String(1 + Math.floor(Math.random() * 20));
      }
    }, 60);
  });
}
