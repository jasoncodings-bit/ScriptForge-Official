"use strict";
/* ============================================================
   Bot editor modal: create/edit/delete/duplicate/share bots,
   avatar image upload, emoji avatars, accent colors,
   advanced character options (scenario, examples, top_p)
   ============================================================ */

const BOT_COLORS = ["", "#7c5cff", "#4bc0ff", "#3ddc84", "#ffb020", "#ff5c6c", "#ff7ad9", "#20c9b7", "#8a94a8"];

let editingBotId = null;   // null = creating a new bot
let editorIcon = "bot";
let editorImage = null;    // dataURL or null
let editorColor = "";      // "" = auto color

function buildIconGrid() {
  const grid = $("emoji-grid");
  grid.innerHTML = "";
  for (const name of AVATAR_ICONS) {
    const b = iconBtn(name, name === editorIcon ? "selected" : "", name);
    b.onclick = () => { editorIcon = name; buildIconGrid(); updateEditorPreview(); };
    grid.appendChild(b);
  }
}

function buildColorSwatches() {
  const wrap = $("color-swatches");
  wrap.innerHTML = "";
  for (const c of BOT_COLORS) {
    const b = el("button", "swatch" + (c === "" ? " none" : "") + (c === editorColor ? " selected" : ""));
    b.type = "button";
    b.title = c === "" ? "Auto (unique color)" : c;
    if (c) b.style.background = c;
    b.onclick = () => { editorColor = c; buildColorSwatches(); updateEditorPreview(); };
    wrap.appendChild(b);
  }
}

function updateEditorPreview() {
  const preview = $("img-preview"), ph = $("img-placeholder"), drop = $("img-drop");
  if (editorImage) {
    preview.src = editorImage;
    preview.hidden = false;
    ph.hidden = true;
    drop.style.background = "";
    $("img-remove-btn").hidden = false;
  } else {
    preview.hidden = true;
    ph.hidden = false;
    $("editor-emoji-big").innerHTML = icon(editorIcon);
    drop.style.background = editorColor || "";
    ph.style.color = editorColor ? "#fff" : "";
    $("img-remove-btn").hidden = true;
  }
}

function openBotEditor(botId) {
  editingBotId = botId || null;
  const bot = botId ? DB.bot(botId) : null;

  $("bot-modal-title").textContent = bot ? "Edit Bot" : "Create a Bot";
  $("bot-name").value = bot ? bot.name : "";
  $("bot-tagline").value = bot ? (bot.tagline || "") : "";
  $("bot-prompt").value = bot ? (bot.prompt || "") : "";
  $("bot-greeting").value = bot ? (bot.greeting || "") : "";
  $("bot-temp").value = bot ? (bot.temp ?? 0.8) : 0.8;
  $("temp-val").textContent = $("bot-temp").value;
  $("bot-scenario").value = bot ? (bot.scenario || "") : "";
  $("bot-example").value = bot ? (bot.example || "") : "";
  $("bot-topp").value = bot ? (bot.topP ?? 1) : 1;
  $("topp-val").textContent = $("bot-topp").value;
  $("bot-nickname").value = bot ? (bot.nickname || "") : "";
  $("bot-adv").open = !!(bot && (bot.scenario || bot.example || bot.nickname || (bot.topP != null && bot.topP < 1)));

  editorIcon = bot ? (bot.icon || "bot") : AVATAR_ICONS[Math.floor(Math.random() * AVATAR_ICONS.length)];
  editorImage = bot ? (bot.image || null) : null;
  editorColor = bot ? (bot.color || "") : "";

  $("bot-delete-btn").hidden = !bot;
  $("bot-duplicate-btn").hidden = !bot;
  $("bot-export-btn").hidden = !bot;

  buildIconGrid();
  buildColorSwatches();
  updateEditorPreview();
  $("bot-modal").classList.add("open");
  $("bot-name").focus();
}

function closeBotEditor() { $("bot-modal").classList.remove("open"); }

/* ---------- image upload / resize ---------- */
function processImageFile(file) {
  if (!file || !file.type.startsWith("image/")) return;
  const img = new Image();
  const url = URL.createObjectURL(file);
  img.onload = () => {
    const MAX = 640;
    let w = img.width, h = img.height;
    const scale = Math.min(1, MAX / Math.max(w, h));
    w = Math.max(1, Math.round(w * scale));
    h = Math.max(1, Math.round(h * scale));
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#1a1e29"; // transparent PNGs get a dark backing
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    editorImage = c.toDataURL("image/jpeg", 0.85);
    URL.revokeObjectURL(url);
    updateEditorPreview();
    toast("Image added — it'll be the bot's cover and avatar");
  };
  img.onerror = () => { URL.revokeObjectURL(url); toast("Couldn't read that image"); };
  img.src = url;
}

function wireBotEditor() {
  /* icon labels on static buttons */
  $("img-upload-btn").innerHTML = icon("image") + "<span>Upload</span>";
  $("img-remove-btn").innerHTML = icon("x") + "<span>Remove</span>";
  $("bot-delete-btn").innerHTML = icon("trash") + "<span>Delete</span>";
  $("bot-duplicate-btn").innerHTML = icon("copy") + "<span>Duplicate</span>";
  $("bot-export-btn").innerHTML = icon("share") + "<span>Share</span>";

  $("bot-temp").addEventListener("input", e => $("temp-val").textContent = e.target.value);
  $("bot-topp").addEventListener("input", e => $("topp-val").textContent = e.target.value);

  const drop = $("img-drop");
  drop.onclick = () => $("bot-img-input").click();
  $("img-upload-btn").onclick = () => $("bot-img-input").click();
  $("bot-img-input").addEventListener("change", e => {
    processImageFile(e.target.files[0]);
    e.target.value = "";
  });
  $("img-remove-btn").onclick = e => {
    e.stopPropagation();
    editorImage = null;
    updateEditorPreview();
  };

  drop.addEventListener("dragover", e => { e.preventDefault(); drop.classList.add("dragover"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("dragover"));
  drop.addEventListener("drop", e => {
    e.preventDefault();
    drop.classList.remove("dragover");
    processImageFile(e.dataTransfer.files[0]);
  });

  $("bot-cancel-btn").onclick = closeBotEditor;
  $("bot-save-btn").onclick = saveBotFromEditor;

  /* Ctrl/Cmd+Enter saves from anywhere in the editor */
  $("bot-modal").addEventListener("keydown", e => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); saveBotFromEditor(); }
  });
  $("bot-delete-btn").onclick = deleteBotFromEditor;
  $("bot-duplicate-btn").onclick = duplicateBotFromEditor;
  $("bot-export-btn").onclick = exportBotFromEditor;
}

function saveBotFromEditor() {
  const name = $("bot-name").value.trim();
  if (!name) { $("bot-name").focus(); toast("Give your bot a name!"); return; }
  const data = {
    name,
    tagline: $("bot-tagline").value.trim(),
    prompt: $("bot-prompt").value.trim(),
    greeting: $("bot-greeting").value.trim(),
    temp: parseFloat($("bot-temp").value),
    scenario: $("bot-scenario").value.trim(),
    example: $("bot-example").value.trim(),
    topP: parseFloat($("bot-topp").value),
    nickname: $("bot-nickname").value.trim(),
    icon: editorIcon,
    image: editorImage,
    color: editorColor
  };
  if (editingBotId) {
    Object.assign(DB.bot(editingBotId), data);
    DB.saveBots();
    closeBotEditor();
    toast("Bot updated");
    refreshAll();
    if (State.view === "chat" && State.botId === editingBotId) renderChatHeader();
  } else {
    data.id = uid("bot");
    data.createdAt = Date.now();
    DB.bots.push(data);
    DB.saveBots();
    closeBotEditor();
    toast("Bot created — say hi!");
    openBotChat(data.id);
  }
}

function deleteBotFromEditor() {
  if (!editingBotId) return;
  const bot = DB.bot(editingBotId);
  if (!confirm('Delete "' + bot.name + '" and ALL of its chats? This cannot be undone.')) return;
  DB.deleteBot(editingBotId);
  if (State.botId === editingBotId) goHome();
  closeBotEditor();
  toast("Bot deleted");
  refreshAll();
}

function duplicateBotFromEditor() {
  if (!editingBotId) return;
  const src = DB.bot(editingBotId);
  const copy = JSON.parse(JSON.stringify(src));
  copy.id = uid("bot");
  copy.name = src.name + " (copy)";
  copy.createdAt = Date.now();
  DB.bots.push(copy);
  DB.saveBots();
  closeBotEditor();
  toast("Duplicated — editing the copy");
  refreshAll();
  openBotEditor(copy.id);
}

function exportBotFromEditor() {
  if (!editingBotId) return;
  const bot = DB.bot(editingBotId);
  downloadJson({ type: "botforge-bot", bot },
    bot.name.replace(/[^\w\- ]+/g, "").trim().replace(/\s+/g, "-").toLowerCase() + ".botforge.json");
  toast("Bot saved as a file — share it with friends!");
}
