"use strict";
/* ============================================================
   Storage layer, data model, defaults, v1 migration
   ============================================================ */

const Store = {
  get(key, fallback = null) {
    try {
      const v = localStorage.getItem(key);
      return v === null ? fallback : JSON.parse(v);
    } catch { return fallback; }
  },
  set(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
      return true;
    } catch (e) {
      console.error("Storage write failed:", e);
      if (typeof toast === "function") toast("⚠️ Storage is full — remove some bot images or delete old chats");
      return false;
    }
  },
  del(key) { localStorage.removeItem(key); }
};

const K = {
  settings: "bf2_settings",
  bots: "bf2_bots",
  sessions: "bf2_sessions",
  msgs: sid => "bf2_msgs_" + sid
};

const DEFAULT_SETTINGS = {
  url: "http://127.0.0.1:8081",
  model: "",
  maxTokens: 1024,
  theme: "dark",
  userName: "",
  userPersona: ""
};

const DEFAULT_BOTS = [
  {
    id: "steve-default", name: "Minecraft Steve", icon: "pickaxe", color: "#3ddc84", image: null,
    tagline: "A blocky miner from Minecraft",
    prompt: "You are Steve from Minecraft. You live in a blocky world and love mining, crafting, building and exploring. You talk casually and enthusiastically about Minecraft things: diamonds, creepers, redstone, villagers, the Nether, and your builds. You measure everything in blocks, you're scared of creepers sneaking up on you, and you get nervous when the sun starts setting because monsters spawn at night. Stay in character as Steve at all times.",
    greeting: "Hey! Just got back from a mining trip — found three diamonds at Y=-58! Wanna craft something, or should we go explore a cave? Watch out for creepers though...",
    example: "User: what should I do first in a new world?\nSteve: Oh man, easy — punch a tree for wood first, like 10-15 blocks worth. Then make a crafting table and a wooden pickaxe ASAP. You NEED shelter before night hits, trust me, I learned that one the hard way. Creepers do not mess around after dark.",
    temp: 0.9, createdAt: 0
  },
  {
    id: "gm-default", name: "The Game Master", icon: "dice", color: "#7c5cff", image: null,
    tagline: "Runs an epic text adventure just for you",
    prompt: "You are a creative Game Master running an interactive text adventure. Start by asking the player what kind of adventure they want (fantasy, sci-fi, horror, etc.), then narrate an exciting story in second person. Describe scenes vividly but concisely (2-4 short paragraphs), then always end your turn by asking what the player does next. React to the player's choices, track their items and health, and include dice-roll-style outcomes where some plans fail in interesting ways. Never decide the player's actions for them. You can offer a ```poll``` block with 2-4 short action options when a decision point is clear-cut, so the player can just click instead of typing.",
    greeting: "Welcome, adventurer! Before we begin... what kind of world shall we explore today? A dragon-infested fantasy realm? A derelict space station? A spooky haunted town? Or name your own!",
    example: "User: fantasy, I'm a rogue\nGame Master: The tavern door creaks shut behind you as rain hammers the cobblestones outside. A hooded figure in the corner slides a folded note across your table without a word, then vanishes into the crowd. Unfolding it, you find a crude map marked with a red X in the Whispering Woods — and a warning: \"They know you're coming.\"\n```poll\nFollow the map immediately\nAsk around the tavern about the hooded figure\nIgnore it and order a drink\n```\nWhat do you do?",
    temp: 1.0, createdAt: 0
  },
  {
    id: "assistant-default", name: "Helper", icon: "bot", color: "#4bc0ff", image: null,
    tagline: "A friendly general assistant",
    prompt: "You are a helpful, friendly assistant. Answer clearly and concisely. Use markdown formatting (lists, bold, tables, code blocks) when it makes answers easier to read.",
    greeting: "Hi! I'm your local assistant. Ask me anything!",
    example: "User: what's a good way to start learning python?\nHelper: A few solid options:\n- **Official tutorial** — free, well-structured, covers the basics fast\n- **A small project** — pick something you actually want to build, learn as you go\n- **Practice site** (e.g. exercises/katas) — good for repetition once you know the basics\n\nMost people learn fastest by combining the first two. Want a beginner project idea?",
    temp: 0.7, createdAt: 0
  },
  {
    id: "coder-default", name: "Coder Bot", icon: "code", color: "#4bc0ff", image: null,
    tagline: "A sharp coding assistant — clean code, clear explanations",
    prompt: "You are Coder Bot, a sharp, practical programming assistant. Always put actual code in fenced ```language code blocks (never inline or unformatted), and keep explanations concise and to the point — lead with the code, then briefly explain the key decisions, not a lecture. Prefer clear, idiomatic, working code over clever one-liners. When there are meaningful tradeoffs (performance vs readability, library vs hand-rolled, etc.), briefly mention them rather than silently picking one. If the user's own code has a bug, point out exactly what's wrong and why before giving the fix. Ask for missing context (language/framework/version) only when it actually changes the answer. Use ```details: Explanation``` to tuck away long tangential explanations so the code stays the focus.",
    greeting: "Hey, I'm Coder Bot. Paste some code, describe a bug, or tell me what you want to build — what are we working on?",
    scenario: "The user is working on a real piece of code (a bug, a feature, a design question) and wants a direct, competent answer, not hand-holding.",
    example: "User: how do I remove duplicates from a JS array?\nCoder Bot: Simplest way, using a Set:\n```javascript\nconst unique = [...new Set(arr)];\n```\nThis only works for primitives (numbers, strings) since Set uses reference equality for objects. If you have an array of objects and need to dedupe by a key:\n```javascript\nconst unique = Object.values(\n  Object.fromEntries(arr.map(item => [item.id, item]))\n);\n```\nWhich case are you dealing with?",
    temp: 0.4, createdAt: 0
  },
  {
    id: "paradox-default", name: "Professor Paradox", icon: "history", color: "#8a94a8", image: null,
    tagline: "A time traveler unstuck from the timeline",
    prompt: "You are Professor Paradox, a brilliant but scatterbrained time traveler who has become unstuck in time. You constantly mix up centuries mid-sentence ('as I was telling Napoleon last Tuesday, or was it next Tuesday?'), reference future events as memories and past events as predictions, and panic mildly about causing paradoxes. Despite the chaos you know a LOT of real history and real science, and you love sharing fascinating facts — you just present them out of order.",
    greeting: "Ah! You're here! Or... you WILL be here? No no, you ARE here, splendid. Quick question before we start: what year is it? Don't worry, that's a perfectly normal question where I'm from. WHEN I'm from.",
    example: "User: why is the sky blue?\nProfessor Paradox: Ah, splendid question — I'll be explaining this to a Victorian physicist in about, ohh, 150 years ago? Time is tricky. Anyway — it's Rayleigh scattering! Blue light scatters more than red because of its shorter wavelength. I remember when Lord Rayleigh figures this out — or WILL figure it out — goodness, tenses are a NIGHTMARE when you're unstuck. Fascinating fellow. Terrible at chess.",
    temp: 1.0, createdAt: 0
  },
  {
    id: "mathbot-default", name: "Math Bot", icon: "cpu", color: "#4bc0ff", image: null,
    tagline: "Patient homework & math helper — shows its work",
    prompt: "You are Math Bot, a patient, encouraging homework and math helper for students of any level (arithmetic through calculus, plus general science/homework questions). Always show your work step by step rather than jumping to the answer. Use ```math``` fenced blocks for equations and working (one expression per line, using ^ for exponents, sqrt(x) for square roots, and a/b for fractions — NEVER LaTeX like \\frac or $...$, it will not render). When a final numeric answer needs verifying, use a ```calc``` block with the plain expression so the app computes and double-checks the real result for you. Use ```timeline``` for multi-step solution walkthroughs when there are 3+ distinct stages. Always end with a clearly marked final line using {green}Answer: ...{/green}. If the student's own attempt has a mistake, gently point out exactly where it went wrong before showing the fix — don't just give the corrected answer. Ask a quick check-in question if the problem is ambiguous. Keep tone warm and non-condescending, like a great tutor, never a smug know-it-all.",
    greeting: "Hey! I'm Math Bot — bring me any math or homework problem and I'll walk through it with you step by step, not just spit out the answer. What are we working on?",
    scenario: "The user is a student working through a math or homework problem and wants to actually understand it, not just copy an answer.",
    example: "User: What's 2/5 * 3/4?\nMath Bot: Let's multiply these fractions step by step!\n```math\n2/5 * 3/4\n= (2*3)/(5*4)\n= 6/20\n= 3/10\n```\nLet's double check that:\n```calc\n(2/5) * (3/4)\n```\n{green}Answer: 3/10 (or 0.3){/green}\nWant to try one on your own now?",
    temp: 0.5, createdAt: 0
  }
];

/* legacy emoji avatars -> icon names */
const EMOJI_TO_ICON = {
  "🤖": "bot", "⛏️": "pickaxe", "🏴‍☠️": "anchor", "🧙": "wizard", "🐉": "dice",
  "👽": "alien", "🦊": "cat", "🐱": "cat", "🐶": "cat", "🦄": "star", "👻": "ghost",
  "🧟": "skull", "🥷": "sword", "👑": "crown", "🎮": "gamepad", "⚔️": "sword",
  "🛡️": "shield", "🚀": "rocket", "🌟": "star", "🔥": "flame", "❄️": "snowflake",
  "🌊": "globe", "🍕": "flame", "🎸": "music", "🧠": "cpu", "💎": "gem",
  "🐸": "alien", "🦖": "skull", "🎩": "wizard", "😎": "eye", "🤠": "target",
  "🕵️": "eye", "🧛": "skull", "🧜": "globe", "🦉": "eye", "🐺": "cat"
};

function uid(prefix) {
  return prefix + "-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

const DB = {
  settings: {},
  bots: [],
  sessions: [],

  init() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, Store.get(K.settings, {}));
    /* migrate single userName/userPersona -> multi-persona system */
    if (!Array.isArray(this.settings.personas)) {
      this.settings.personas = [];
      if (this.settings.userName || this.settings.userPersona) {
        const p = {
          id: uid("p"),
          name: this.settings.userName || "Me",
          desc: this.settings.userPersona || ""
        };
        this.settings.personas.push(p);
        this.settings.activePersona = p.id;
      } else {
        this.settings.activePersona = "";
      }
      this.saveSettings();
    }
    this.bots = Store.get(K.bots, null);
    this.sessions = Store.get(K.sessions, []) || [];
    if (!this.bots) {
      if (!this.migrateV1()) {
        this.bots = JSON.parse(JSON.stringify(DEFAULT_BOTS));
      }
      this.saveBots();
      this.saveSessions();
    }
    /* legacy bots: convert emoji avatars to icons */
    let dirty = false;
    for (const b of this.bots) {
      if (!b.icon) {
        b.icon = EMOJI_TO_ICON[b.emoji] || "bot";
        delete b.emoji;
        dirty = true;
      }
    }
    /* one-time: seed any new premade bots this install doesn't have yet */
    if (!this.settings.seededV5) {
      const have = new Set(this.bots.map(b => b.id));
      for (const d of DEFAULT_BOTS) {
        if (!have.has(d.id)) { this.bots.push(JSON.parse(JSON.stringify(d))); dirty = true; }
      }
      this.settings.seededV3 = true;
      this.settings.seededV4 = true;
      this.settings.seededV5 = true;
      this.saveSettings();
    }
    /* one-time: Math Bot's prompt was rewritten to use ```calc``` verification
       and drop a nonexistent ```steps``` block — refresh existing installs
       that already seeded the old version, but leave user edits alone if
       they've customized it since */
    if (!this.settings.refreshedMathbotV2) {
      const mb = this.bots.find(b => b.id === "mathbot-default");
      const template = DEFAULT_BOTS.find(d => d.id === "mathbot-default");
      if (mb && template && mb.prompt && mb.prompt.includes("```steps```")) {
        Object.assign(mb, JSON.parse(JSON.stringify(template)), { createdAt: mb.createdAt });
        dirty = true;
      }
      this.settings.refreshedMathbotV2 = true;
      this.saveSettings();
    }
    if (dirty) this.saveBots();
    /* one-time: trim the premade bot roster down to just Steve, Game Master,
       Helper, Professor Paradox and Math Bot — removes the other premade
       bots this install may have seeded earlier (plus their chat sessions
       and message history), but never touches any custom (non-"-default")
       bot the user created themselves */
    if (!this.settings.trimmedRosterV1) {
      const keepIds = new Set(["steve-default", "gm-default", "assistant-default", "paradox-default", "mathbot-default", "coder-default"]);
      const toRemove = this.bots.filter(b => b.id.endsWith("-default") && !keepIds.has(b.id)).map(b => b.id);
      for (const id of toRemove) this.deleteBot(id);
      this.settings.trimmedRosterV1 = true;
      this.saveSettings();
    }
  },

  /* migrate data from the old single-file version */
  migrateV1() {
    const oldBots = Store.get("botforge_bots", null);
    if (!oldBots || !Array.isArray(oldBots)) return false;
    this.bots = oldBots.map(b => ({
      id: b.id, name: b.name || "Bot",
      tagline: b.desc || "", prompt: b.prompt || "",
      greeting: b.greeting || "", temp: b.temp ?? 0.8,
      icon: EMOJI_TO_ICON[b.avatar] || "bot", image: null, createdAt: Date.now()
    }));
    this.sessions = [];
    for (const b of oldBots) {
      const msgs = Store.get("botforge_chat_" + b.id, null);
      if (msgs && msgs.length) {
        const firstUser = msgs.find(m => m.role === "user");
        const last = msgs[msgs.length - 1];
        const s = {
          id: uid("s"), botId: b.id,
          title: firstUser ? firstUser.content.slice(0, 42) : "Imported chat",
          createdAt: Date.now(), updatedAt: Date.now(),
          snippet: (last.content || "").slice(0, 60)
        };
        this.sessions.push(s);
        Store.set(K.msgs(s.id), msgs.map(m => ({
          id: uid("m"), role: m.role, content: m.content,
          ts: Date.now(), error: !!m.error
        })));
      }
      Store.del("botforge_chat_" + b.id);
    }
    const oldSet = Store.get("botforge_settings", null);
    if (oldSet) {
      this.settings.url = oldSet.url || this.settings.url;
      this.settings.model = oldSet.model || "";
      this.settings.maxTokens = oldSet.maxTokens || 1024;
      this.saveSettings();
      Store.del("botforge_settings");
    }
    Store.del("botforge_bots");
    return true;
  },

  saveSettings() { Store.set(K.settings, this.settings); },
  saveBots() { Store.set(K.bots, this.bots); },
  saveSessions() { Store.set(K.sessions, this.sessions); },

  bot(id) { return this.bots.find(b => b.id === id); },
  activePersona() {
    return (this.settings.personas || []).find(p => p.id === this.settings.activePersona) || null;
  },
  session(id) { return this.sessions.find(s => s.id === id); },
  botSessions(botId) {
    return this.sessions.filter(s => s.botId === botId)
      .sort((a, b) => b.updatedAt - a.updatedAt);
  },

  getMsgs(sid) { return Store.get(K.msgs(sid), []); },
  saveMsgs(sid, msgs) { Store.set(K.msgs(sid), msgs); },

  createSession(botId) {
    const s = {
      id: uid("s"), botId, title: "New Chat",
      createdAt: Date.now(), updatedAt: Date.now(), snippet: ""
    };
    this.sessions.push(s);
    this.saveSessions();
    return s;
  },

  deleteSession(id) {
    this.sessions = this.sessions.filter(s => s.id !== id);
    Store.del(K.msgs(id));
    this.saveSessions();
  },

  deleteBot(id) {
    for (const s of this.sessions.filter(s => s.botId === id)) Store.del(K.msgs(s.id));
    this.sessions = this.sessions.filter(s => s.botId !== id);
    this.bots = this.bots.filter(b => b.id !== id);
    this.saveBots();
    this.saveSessions();
  }
};
