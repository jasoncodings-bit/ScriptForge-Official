"use strict";
/* ============================================================
   Home view: bot gallery cards
   ============================================================ */

function lastActivity(bot) {
  const ss = DB.botSessions(bot.id);
  return ss.length ? ss[0].updatedAt : (bot.createdAt || 0);
}

function renderHome() {
  const grid = $("bot-grid");
  grid.innerHTML = "";
  const q = ($("home-search").value || "").trim().toLowerCase();

  const create = el("div", "bot-card create-card");
  const inner = el("div", "create-inner");
  const plus = el("div", "plus");
  plus.innerHTML = icon("plus");
  inner.appendChild(plus);
  inner.appendChild(el("div", "", "Create a Bot"));
  inner.appendChild(el("div", "sub", "Forge a brand new character"));
  create.appendChild(inner);
  create.onclick = () => openBotEditor(null);
  grid.appendChild(create);

  const sorted = DB.bots.slice().sort((a, b) => lastActivity(b) - lastActivity(a));
  for (const bot of sorted) {
    if (q && !((bot.name + " " + (bot.tagline || "")).toLowerCase().includes(q))) continue;
    grid.appendChild(botCard(bot));
  }
}

function botCard(bot) {
  const card = el("div", "bot-card");

  const cover = el("div", "card-cover");
  if (bot.image) {
    const img = el("img");
    img.src = bot.image;
    img.alt = "";
    cover.appendChild(img);
  } else {
    cover.style.background = botColor(bot);
    const big = el("div", "cover-icon");
    big.innerHTML = icon(bot.icon || "bot");
    cover.appendChild(big);
  }
  const edit = iconBtn("edit", "card-edit", "Edit bot");
  edit.onclick = e => { e.stopPropagation(); openBotEditor(bot.id); };
  cover.appendChild(edit);
  card.appendChild(cover);

  const body = el("div", "card-body");
  body.appendChild(el("div", "card-name", bot.name));
  body.appendChild(el("div", "card-tag", bot.tagline || ""));

  const foot = el("div", "card-foot");
  const n = DB.botSessions(bot.id).length;
  foot.appendChild(el("span", "card-chats", n ? n + (n === 1 ? " chat" : " chats") : "No chats yet"));
  const btn = iconBtn("chat", "card-chat-btn", "Chat with " + bot.name, "Chat");
  btn.onclick = e => { e.stopPropagation(); openBotChat(bot.id); };
  foot.appendChild(btn);
  body.appendChild(foot);
  card.appendChild(body);

  card.onclick = () => openBotChat(bot.id);
  return card;
}
